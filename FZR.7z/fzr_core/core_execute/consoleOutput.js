const fs = require("fs");
const core_execute = require("./")
const core_errmgr = require("../core_errmgr/");
const core_variables = require("../core_variables/")



function isOutput(line,workingline) 
{
	if (!line.match(regexList["outputData"])) return;
	var val = purify_content(line);
	if (getValueType(val) === "var") val = getVariable(val,workingline);
	if (val.match(regexList["stringRegex"])) { val = val.slice(1,-1)}
	console.log(val)
}


function purify_content(line) {
	line = line.replace("say(" , "");
	line = line.slice(0, -1);
	return line;
}




function getVariable(value,workingline) 
{
	var toreturn;
	Object.keys(core_execute.valuesList).forEach(function(key) 
	{
    	if (core_execute.valuesList[key]["name"] === value)  { toreturn = core_execute.valuesList[key]["value"]; }
	});
	if ( typeof toreturn === 'undefined' && !toreturn )	core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Undefined variable called : ${core_variables.clr_green}${value}${core_variables.clr_white} at line ${workingline}`)
	return toreturn;
}

function isDefineVar(line)
{
	if (line.match(regexList["defineVar"])) return true; else return false;
}


function setVar(type,name,value,workingline) 
{
	if (type !== getValueType(value)) 
	{
		core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Trying to set ${value} (${getValueType(value)}) as ${type} at line ${workingline}`)
	}
	core_execute.valuesList.push({name,value});	
}


function getValueType(value) {
if (/^\d+$/.test(value)) { return "int"; };
if (value === "true" || value === "false") { return "bool"; };
if (value.match(regexList["stringRegex"])) { return "str"; };
return "var";
}


exports.isOutput = isOutput;
var regexList =
{	
	"outputData" : /(say[(](.){0,}\))/gmi,
	"stringRegex" : /"(.){0,}"/gmi

}