const core_execute = require("./")
const core_errmgr = require("../core_errmgr/");
const core_variables = require("../core_variables/")





function isDefineVar(line)	{	if (line.match(regexList["defineVar"])) return true; else return false;		}
function setVar(type,name,value,workingline) 
{
	if (type !== getValueType(value)) 
	{
		core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Trying to set ${value} (${getValueType(value)}) as ${type} at line ${workingline}`)
	}
	core_execute.valuesList.push({name,value});	
}



function purify_content(line) {

}












function getValueType(value) {
if (/^\d+$/.test(value)) { return "int"; };
if (value === "true" || value === "false") { return "bool"; };
if (value.match(regexList["stringRegex"])) { return "str"; };
return "var";
}

function getVariable(value,workingline) 
{
	var toreturn;
	Object.keys(core_execute.valuesList).forEach(function(key) 
	{
    	if (core_execute.valuesList[key]["name"] === value)  { toreturn = core_execute.valuesList[key]["value"]; }
	});
	if ( typeof toreturn === 'undefined' && !toreturn )	core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Undefined variable called : ${core_variables.clr_green}${value}${core_variables.clr_white} at line ${workingline}`)

return toreturn
}






exports.setVar = setVar;
exports.isDefineVar = isDefineVar;
var regexList =
{	
	"defineVar" : /(int|bool|str) ([a-zA-Z0-9]){0,20} ("(.){0,}"|true|false|[0-9A-z]{0,})/gmi, // int xxx 57
	"ifContent_0" : /[?]( \(|\()["\[\]a-zA-Z0-9 =+\-\*.\(\)]{0,150}( \)|\))/gmi, // Base if content  : ? ()
	"concateVar" : /(str [A-z0-9]{0,} \(.{0,},.{0,})/gmi, // str coucou (str1 str2)
	"ifStatement_L1" : /["\[\]a-zA-Z0-9]{1,30}(( )|())(===|==|=|\+|-|\/|!==)(( )|())["\[\]a-zA-Z0-9]{1,30}/gmi,
	"stringRegex" : /"(.){0,}"/gmi
}