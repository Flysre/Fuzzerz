const core_execute = require("./")
const core_errmgr = require("../core_errmgr/");
const core_variables = require("../core_variables/")
function isIfStatement(line)  {	if (line.match(regexList["ifContent_0"])) return true; else return false;	};



function calculateValue(line,workingline) {
	line = line.replace("? (" , "");
	line = line.slice(0, -1);
	var purify =  line.split(" ")
	/// IF CODE
	if (purify[0].length < 1) core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid if usage. If content can't be null at line ${workingline}`)
	if (purify.length === 2)  core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid if usage. If content can't contain two values at line ${workingline}`)
	if (!["===","==","-","<",">"].includes(purify[1])) core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid if usage. Operator ${purify[1]} can only be ${["===","==","-","<",">"]} at line ${workingline}`)
	if (purify.length === 1)  if (purify[0] === "true") return true; else return false;
	var val1 = purify[0]
	var val2 = purify[2]
	// calculate length
	if (val1.endsWith(".lgt()")){val1 = val1.split(".lgt()").join("").split('"').join("")
		if (getValueType(val1) === "bool" || getValueType(val1) === "int") core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid if usage. Cannot get length of ${getVariable(val1,workingline)} at line ${workingline}`)
		val1 = getVariable(val1,workingline).slice(1,-1).length;
		
}
	if (val2.endsWith(".lgt()")) {val2 = val2.split(".lgt()").join("").split('"').join("")
		if (getValueType(val2) === "bool" || getValueType(val2) === "int") core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid if usage. Cannot get length of ${getVariable(val2,workingline)} at line ${workingline}`)
		val2 = getVariable(val2,workingline).slice(1,-1).length;
	}
	//////////////////////////////////////////////

	var operator = purify[1]
	// console.log(`CALCULATE VALUE :  ${val1} ${operator} ${val2}`)
	if (getValueType(val1) === "var") {val1 = getVariable(val1,workingline);}
	if (getValueType(val2) === "var") {val2 = getVariable(val2,workingline);}
	switch (operator) 
	{
		case '===' :
		if (getValueType(val1) !== getValueType(val2)) return false;
		if (val1 == val2) return true; else return false;
		break;
	
		case '==' :
		if (val1 == val2) return true; else return false;
		break;
	}
}


function getValueType(value) {
if (/^\d+$/.test(value)) { return "int"; };
if (value === "true" || value === "false") { return "bool"; };
if (value.match(regexList["stringRegex"])) { return "str"; };
return "var";
}

function getVariable(value,workingline) 
{
	var toreturn;
	Object.keys(core_execute.valuesList).forEach(function(key) 
	{
    	if (core_execute.valuesList[key]["name"] === value)  { toreturn = core_execute.valuesList[key]["value"]; }
	});
	if ( typeof toreturn === 'undefined' && !toreturn )	core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Undefined variable called : ${core_variables.clr_green}${value}${core_variables.clr_white} at line ${workingline}`)

return toreturn
}





	


function setVar(type,name,value,workingline) 
{
	if (type !== getValueType(value)) 
	{
		core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Trying to set ${value} (${getValueType(value)}) as ${type} at line ${workingline}`)
	}
	core_execute.valuesList.push({name,value});	
}


exports.calculateValue = calculateValue;
exports.isIfStatement = isIfStatement;
exports.getValueType = getValueType;
exports.setVar = setVar;

var regexList =
{	
	"defineVar" : /(int|bool|str) ([a-zA-Z0-9]){0,20} ("(.){0,}"|true|false|[0-9]{0,})/gmi, // int xxx 57
	"ifContent_0" : /[?]( \(|\()["\[\]a-zA-Z0-9 =+\-\*.\(\)]{0,150}( \)|\))/gmi, // Base if content  : ? ()
	"ifStatement_L1" : /["\[\]a-zA-Z0-9]{1,30}(( )|())(===|==|=|\+|-|\/|!==)(( )|())["\[\]a-zA-Z0-9]{1,30}/gmi,
	"stringRegex" : /"(.){0,}"/gmi
}