const fs = require("fs");
const core_errmgr = require("../core_errmgr/");
const core_variables = require("../core_variables/");

const ifAnalyser = require("./IfAnalyser");
const consoleOutput = require("./consoleOutput");
const var_set = require("./var_set")

var valuesList = [];
module.exports.valuesList = valuesList;
var workingline = 0

// Managing If memmory all over the code.
var ifDeepness = -1;
var ifCalledLine = [];

function run(scriptPath) {
    const data = fs.readFileSync(scriptPath[0], 'UTF-8').split("	").join("");

    // split the contents by new line
    const lines = data.split(/\r?\n/);

    // TODO : Put if's inside other ifs (Semi working)

    // print all lines
    lines.forEach((line) => 
    {workingline++	
    	// console.log(`LINE : ${workingline}         Deepness[${ifDeepness}]`)
    	// console.log(CXorkingline)	
    	// Analyse Line Deepness
    	if (line.startsWith("<<")) {
    		if (ifDeepness > -1) if (ifCalledLine[ifDeepness]["line"] !== workingline + 1) core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid If function invalid or useless << at line ${workingline}`)
    		
    		ifDeepness++
    	}
    	if (line.startsWith(">>")) { 
    		ifCalledLine.splice(ifCalledLine[ifDeepness]);
    		ifDeepness-- 
    	}

       	if (ifCalledLine.length > 0) 
       	{ 
       		if (!ifCalledLine[ifDeepness]["result"]) { return;}
       	}

   		if (ifAnalyser.isIfStatement(line))  {ifCalledLine.push({"line": workingline, "result": ifAnalyser.calculateValue(line,workingline)}); }
 		//////////////////////////////////////////////////


 		if (var_set.isDefineVar(line))
    	{
    		var splited = line.split(" ");
    		if (splited.length < 3)  core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Invalid value defining at line ${workingline}`)
    		ifAnalyser.setVar(splited[0],splited[1],splited[2],workingline)
    	}

    	// Automaticly check and run the thingo
    	consoleOutput.isOutput(line,workingline);
    	if (line.startsWith(">exit")) { console.log(`${core_variables.clr_white}[${core_variables.clr_yellow}!${core_variables.clr_white}] Exit trigger detected.`); process.exit();}

    });
}




















exports.run = run;
