const core_check = require("./core_check/");
const core_errmgr = require("./core_errmgr/");
const core_variables = require("./core_variables/")
const core_execute = require("./core_execute/")
function execute(scriptPath){
if (!core_check.file_presence(scriptPath)) {	core_errmgr.send_err(`${core_variables.clr_white}[${core_variables.clr_red}ERROR${core_variables.clr_white}] Input file not found : ${scriptPath}`)	};
core_execute.run(scriptPath);
}

exports.execute = execute;
