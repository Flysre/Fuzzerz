const fs = require("fs");
function file_presence(scriptPath){
if (fs.existsSync(scriptPath[0])) { return true;} else {return false;}
}


exports.file_presence = file_presence;
