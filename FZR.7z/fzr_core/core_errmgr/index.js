const fs = require("fs");
function send_err(error){
console.log(error);
console.log("Exiting.")
process.exit();
}

exports.send_err = send_err;
